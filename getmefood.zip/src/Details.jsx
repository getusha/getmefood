import "./App.css";
import {useLocation} from "react-router-dom";
import axios from "axios";
import { useState } from "react";

export default function Details(props){

    const [mealDetail, setMealDetail] = useState();
    const location = useLocation();
    const currentLocation = location.pathname;
///recipe/98787
    const mealID = currentLocation.slice(8,currentLocation.length)
    console.log(mealID)
    axios.get(`https://themealdb.com/api/json/v1/1/lookup.php?i=${52948}`)
    .then((result)=>{
        setMealDetail((prev)=>{
            return result.data.meals.strMeal;
        })
    })
    return(
        <>
        <div className="recipe-d">
            <div className="card">
                <h3>{mealDetail}</h3>
                <h2>{props.title}</h2>
                <p>{props.instruction}</p>
            </div>
        </div>
        </>
    )
}