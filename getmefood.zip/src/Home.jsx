import Recipe from "./Recipe";
import { Link } from "react-router-dom";
import { useState } from "react";
import axios from "axios";
import Details from "./Details";


export default function Home(props) {
  const [passFood, setPassFood] = useState();

  function clickPassData(id) {
    axios.get(`https://themealdb.com/api/json/v1/1/lookup.php?i=${id}`)
    .then((result)=>{
        setPassFood(result.data.meals)
        console.log(result.data.meals)
        return <Details title={result.data.meals.idMeal} />
    })
  }

  return (
    <>
      <div className="App">
        <div className="top-container">
          <h1 className="main-title">Search Any Food You need</h1>
          <input
            onChange={props.handleSearch}
            className="main-input"
            type={"text"}
            placeholder={"food...recipes"}
          />
        </div>
        <div className="mid-container">
          {props.feedFoods !== null &&
            props.feedFoods.map((element, index) => {
              return (
                <>
                  <Recipe
                    something={() => clickPassData(element.idMeal)}
                    linkPage={"/recipe/"+element.idMeal}
                    key={element.idMeal}
                    title={element.strMeal}
                    image={element.strMealThumb}
                    country={element.strArea}
                    category={element.strCategory}
                  />
                </>
              );
            })}
        </div>
      </div>
    </>
  );

}
